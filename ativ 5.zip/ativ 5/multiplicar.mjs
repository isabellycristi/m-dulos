export function multiplicador(a, b) {
    return a * b;
}